﻿
using UnityEngine;

public class collision : MonoBehaviour 
{
    public float death_rate;

    private void Start()
    {
        death_rate = Random.Range(60, 100);
    }

    public void OnCollisionEnter(Collision collisionInfo)
    {
        

        Debug.Log(collisionInfo.gameObject.name);

        if (collisionInfo.gameObject.tag == "infected")
        {
            if (gameObject.tag != collisionInfo.gameObject.tag)
            {
                
                gameObject.tag = "infected";
                gameObject.GetComponent<Renderer>().material.color = collisionInfo.gameObject.GetComponent<Renderer>().material.color;
                    // Debug.Log("Person going for shopping has age " + collisionInfo.gameObject.GetComponent<Enemy>().age);
            }

       
                //gameObject.GetComponent<Renderer>().material.color = collisionInfo.gameObject.GetComponent<Renderer>().material.color;
            }

        }
    }

