﻿using UnityEngine;

public class Enemy : MonoBehaviour
{
   


 
    public Transform[] target;
    public float speed;
    private int current;
    public int age;
    public float survival_rate;

    void Start()
    {
        age = Random.Range(1, 60);

        if(age >= 50)
        {
            survival_rate = Random.Range(10,40);
        }
        else if(age < 50)
        {
            survival_rate = Random.Range(60, 100);
        }
            

    }

        
    // Update is called once per frame
    void Update()
    {
        speed = Random.Range(1f, 2f);
        if (transform.position != target[current].position )
        
            
            { 
                Vector3 pos = Vector3.MoveTowards(transform.position, target[current].position, speed * Time.deltaTime);
                GetComponent<Rigidbody>().MovePosition(pos);
            }



        else current = (current + 1) % target.Length;
    }
}



