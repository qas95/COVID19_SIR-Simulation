﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class death : MonoBehaviour
{
    public float deathrate;

    // Start is called before the first frame update
    void Start()
    {
        deathrate = Random.Range(50, 100);
    }

    // Update is called once per frame
    private void OnCollisionEnter(Collision collisionInfo)
    {
        if (collisionInfo.gameObject.tag == "infected" & gameObject.GetComponent<prayer>().survival_rate <= deathrate)

        {
            gameObject.tag = "d";
            gameObject.GetComponent<Renderer>().material.color = Color.red;
        }

        else if (collisionInfo.gameObject.tag == "infected" & gameObject.GetComponent<prayer>().survival_rate > deathrate)

        {
            gameObject.tag = "infected";
            gameObject.GetComponent<Renderer>().material.color = Color.green;
        }
    }

}
